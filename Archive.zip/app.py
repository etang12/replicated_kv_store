from flask import Flask, jsonify, json, request, Response
from flask.globals import current_app
from requests.api import delete
from requests.exceptions import ConnectionError, Timeout
import requests
import os
import logging
import time

app = Flask(__name__)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

db = {}
up_replicas = []
down_replicas = []
# initialize view to grab environment variable "VIEW" which contains default string of replicas
# grab socket address of the container
logging.info("-----------------START OF CODE-------------------")
view = os.getenv('VIEW').split(',')
thisVC = {}
for v in view:
    thisVC[v] = 0
current_ip = os.environ['SOCKET_ADDRESS']
logging.info(f"SOCKET ADDRESS: {current_ip}, VIEW: {view}")
sync_flag = True

TIMEOUT = 3

@app.route("/key-value-store/<key>/<is_forwarded>", methods=['PUT', 'GET', 'DELETE'])
@app.route("/key-value-store/<key>", defaults={'is_forwarded': False}, methods=['PUT', 'GET', 'DELETE'])
def key_value_store(key, is_forwarded):
    # check if in current replica instance
    global current_ip
    logging.debug(f"\n\nthe current ip: {current_ip}\nis forwarded? {is_forwarded}\n")
    global thisVC
    global view
    otherVC = request.json['causal-metadata']
    if otherVC == "":
        otherVC = {}
        for v in view:
            otherVC[v] = 0
    # logging.debug(f"the type of the recieved vector clock: {type(otherVC)}")
    # logging.debug(f"the recieved vector clock: {otherVC}")
    delayMessage = False 
    # true if otherVC > thisVC (other happens after this)
    # false if otherVC <= thisVC (other is concurrent (causally independant) or happens before this)
    if otherVC != "" and is_forwarded == False:
        # logging.debug(f"the recieved vector clock: {otherVC}")
        # logging.debug(f"the current vector clock: {thisVC}")
        for v in view:
            if otherVC[v] > thisVC[v]:
                # thisVC[v] = otherVC[v]
                #MIGHT NEED TO CHANGE ABOVE LINE OF CODE GO THROUGH LOGIC AGAIN LATER BUT IM PRETTY SURE ITS CORRECT
                delayMessage = True
            if otherVC[v] < thisVC[v]:
                delayMessage = False
                break
    
    if not delayMessage:
        # if is_forwarded == False:
        
        if request.method == 'PUT':
            
            put_resp = {}
            if len(key) > 50:
                msg = {"error":"Key is too long","message":"Error in PUT"}
                return Response(
                    json.dumps(msg), status=400, mimetype='application/json'
                )
            # if string 'value' exists in the request data
            if 'value' in request.json:
                
                if is_forwarded == False:
                    # logging.debug(f"ip address recieving the client: {current_ip}")
                    for v in view:
                        if otherVC[v] > thisVC[v]:
                            thisVC[v] = otherVC[v]
                        if v == current_ip:
                            thisVC[v] += 1
                    for v in view:
                        if v != current_ip:
                            forward_store(v, key, True, thisVC)
                else:
                    # logging.debug(f"ip address recieving from the broadcast replica: {current_ip}")
                    thisVC = otherVC
                 # state change!

                value = request.json['value']
                if key not in db:
                    # logging.debug("adding new key")
                    db[key] = value
                    put_resp['message'] = "Added successfully"
                    put_resp['causal-metadata'] = thisVC
                    # put_resp['replaced'] = False
                    status = 201
                else:
                    # logging.debug("updating old key")
                    db[key] = value
                    put_resp['message'] = "Updated successfully"
                    put_resp['causal-metadata'] = thisVC
                    # put_resp['replaced'] = True
                    status = 200
                    # msg = {"message":"Updated successfully","replaced":True}
            else:
                put_resp['error'] = "Value is missing"
                put_resp['message'] = "Error in PUT"
                status = 400

            return Response(
                json.dumps(put_resp), status=status, mimetype='application/json'
            )

        elif request.method == 'GET':
            get_resp = {}
            if key in db:
                value = db[key]
                # get_resp['doesExist'] = True
                get_resp['message'] = "Retrieved successfully"
                get_resp['causal-metadata'] = thisVC
                get_resp['value'] = value
                status = 200
            else:
                get_resp['doesExist'] = False
                get_resp['error'] = "Key does not exist"
                get_resp['message'] = "Error in GET"
                status = 404

            return Response(
                json.dumps(get_resp), status=status, mimetype='application/json'
            )

        elif request.method == 'DELETE':
            del_resp = {}
            if key in db:
                if is_forwarded == False:
                    for v in view:
                        if otherVC[v] > thisVC[v]:
                            thisVC[v] = otherVC[v]
                        if v == current_ip:
                            thisVC[v] += 1
                    for v in view:
                        if v != current_ip:
                            forward_store(v, key, True, thisVC)
                else:
                    thisVC = otherVC
                 # state change!

                del db[key]

                # state change!

                # del_resp['doesExist'] = True
                del_resp['message'] = "Deleted successfully"
                del_resp['causal-metadata'] = thisVC
                status = 200
            else:
                del_resp['doesExist'] = False
                del_resp['error'] = "Key does not exist"
                del_resp['message'] = "Error in DELETE"
                status = 404
            
            return Response(
                json.dumps(del_resp), status=status, mimetype='application/json'
            )
    else:
        print("message delayed")
        del_resp = {}
        del_resp['error: server clock needs to catch up'] = "Sorry! Try again in a few seconds!"
        return Response(
                json.dumps(del_resp), status=503, mimetype='application/json'
            )

# view operations
@app.route("/key-value-store-view", methods=['GET', 'PUT', 'DELETE'])
def key_value_view():
    #logging.info(view)
    # grab current replica's IP and store in current_ip
    # set the current replica's view to be the default view (grabbed from environment variable), can be found at top of file
    global view
    global current_ip
    # if sync_flag:
    #     sync_view()
    # neighbor_replicas = list(view)
    # to_broadcast_put = True
    # to_broadcast_delete = True
    # view = set(view)
    # #logging.info(view)
    # view.remove(current_ip) # remove current_ip (current replica) from view to prevent sending PUT, DELETE requests to itself
    # view = list(view)
    logging.info("------------------IN KEY VALUE FUNCTION------------------")
    logging.info(f"CURRENT REPLICA IP: {current_ip}")
    # time.sleep(2)

    # GET
    if request.method == 'GET':
        # if current_ip not in view:
        #     view.append(current_ip)
        logging.info(view)
        data = {"message":"View retrieved successfully","view":view}
        status = 200
        # for v in view:
        #     forward_view(v)
        return Response(
            json.dumps(data), status=status, mimetype='application/json'
        )

    # PUT
    if request.method == 'PUT':
        data = request.get_json()
        # if data.get('broadcast_flag') is not None:
        #     to_broadcast_put = False
        #logging.info(data)
        replica_added_ip = data.get("socket-address")
        if replica_added_ip in view:
            err_msg = {"error":"Socket address already exists in the view","message":"Error in PUT"}
            status = 404
            return Response(
                json.dumps(err_msg), status=status, mimetype='application/json'
            )
        else:
            view = set(view)
            # logging.info(f"VIEW before PUT in key-value-view: {view}")
            view.add(replica_added_ip)
            view = list(view)
            # logging.info(f"VIEW after PUT in key-value-view: {view}")
            msg = {"message":"Replica added succesfully to the view"}
            status = 201
            # if to_broadcast_put:
            #     # logging.info(f"neighbor_replicas in PUT: {neighbor_replicas}")
            #     # for ip in neighbor_replicas:
            #     for ip in neighbor_replicas:
            #         # time.sleep(1)
            #         logging.info(f"IP IN PUT FOR LOOP:{ip}")
            #         if ip != current_ip:
            #             forward_view(ip, data, neighbor_replicas)
            #view.append(current_ip)
            return Response(
                json.dumps(msg), status=status, mimetype='application/json'
            )

    # DELETE
    if request.method == 'DELETE':
        data = request.get_json()
        # if data.get('broadcast_flag') is not None:
        #     to_broadcast_delete = False
        logging.info(f"\n\n -----------------IN DELETE-------------------")
        logging.info(f"DELETE data: {data}")
        # logging.info(data)
        replica_deleted_ip = data.get("socket-address")
        #logging.info(view)
        # logging.info(replica_deleted_ip)
        if replica_deleted_ip in view:
            view = set(view)
            view.remove(replica_deleted_ip)
            view = list(view)
            # logging.info(view)
            msg = {"message":"Replica deleted successfully from the view"}
            status = 200
            # if to_broadcast_delete:
            #     for ip in neighbor_replicas:
            #         if ip != current_ip:
            #             forward_view(ip, data, neighbor_replicas)
            return Response(
                json.dumps(msg), status=status, mimetype='application/json'
            )
        else:
            msg = {"error":"Socket address does not exist in the view", "message":"Error in DELETE"}
            status = 404
            return Response(
                json.dumps(msg), status=status, mimetype='application/json'
            )

# forwarding function for key-value-store
def forward_store(address, key, is_forwarded, metadata):
    #create the endpoint we wish to forward requests to
    # logging.debug(f"\n\nthe address that we are forwarding to is: {address}\n")
    forward_endpoint = f"http://{address}/key-value-store/{key}/{is_forwarded}"
    #attempt to send requests to that endpoint
    logging.info(f"forward_endpoint: {forward_endpoint}")
    if request.method == 'PUT':
        data = request.get_json()
        value = data.get('value')
        new_data = {"value": value, "causal-metadata": metadata}
        # logging.debug(f"\n\nforwarding endpoint: {forward_endpoint}\nr: {r}\nr.content: {r.content}\nr.status_code: {r.status_code}\n")
        logging.debug(f"\n\nforwarding endpoint: {forward_endpoint}\n")
        try_request(url=forward_endpoint, data=new_data, method=request.method, target_ip=address)
        # logging.debug(f"\n\nthe r.url value: {r.url}\n")
    elif request.method == 'GET':
        try_request(url=forward_endpoint)
    elif request.method == 'DELETE':
        new_data = {"causal-metadata": metadata}
        try_request(url=forward_endpoint, data=new_data, method=request.method, target_ip=address)


    # logging.debug(f"\n\nr.content: {r.content}\nr.status_code: {r.status_code}\n")

# sync db to new replicas
def sync_db():
    pass

# update view by sending GET requests to all replicas in initial view
# helps ensure new replicas retrieve the most updated view (syncs view for new replicas)
# checks for downed replicas and removes from view
# def sync_view():
#     global view
#     global sync_flag
#     logging.info("\n\n\nINSIDE SYNC_VIEW")
#     # updated_view = []
#     for replica_ip in view:
#         replica_endpoint = f"http://{replica_ip}/key-value-store-view"
#         logging.info(f"REPLICA IP ENDPOINT THAT WE ARE GETTING: {replica_endpoint}")
#         sync_flag = False
#         if replica_ip != current_ip:
#             try:
#                 response = requests.get(replica_endpoint)
#                 # logging.info(f"response: {response}, {response.json()}")
#                 # updated_view = response.json().get('view')
#                 view = response.json().get('view')
#                 logging.info(f"updated view: {view}")
#             except Exception as e:
#                 if replica_ip in view:
#                     logging.info(f"before DELETE view in get_view: {view}")
#                     logging.info(f"replica to delete: {replica_ip}")
#                     view = set(view)
#                     view.remove(replica_ip)
#                     logging.info(f"after DELETE view in get_view: {view}")
#                     view = list(view)
#                 for v in view:
#                     if current_ip != v:
#                         target_replica = f"http://{v}/key-value-store-view"
#                         if v != replica_ip:
#                             r = requests.delete(target_replica, json={"socket-address": replica_ip})
# send GET requests to every replica in VIEW
# if request fails, store that replica IP in down_replicas
# if request succeeds, store that replica IP in up_replicas
# return up_replicas and set as new view
# then broadcast PUT request to the new view
def check_replicas():
    global view
    global up_replicas
    global down_replicas
    for replica_ip in view:
        # don't send request to itself (current replica)
        if replica_ip != current_ip:
            replica_endpoint = f"http://{replica_ip}/key-value-store-view"
            try:
                r = requests.get(replica_endpoint)
                up_replicas = set(up_replicas)
                up_replicas.add(replica_ip)
                up_replicas = list(up_replicas)
            except:
                down_replicas = set(down_replicas)
                down_replicas.add(replica_ip)
                down_replicas = list(down_replicas)
                logging.info(f"view in check_replicas: {view}, replica_ip: {replica_ip}")
                view = set(view)
                view.remove(replica_ip)
                view = list(view)
                if len(up_replicas) != 0:
                    for ip in up_replicas:
                            delete_replica_endpoint = f"http://{ip}/key-value-store-view"
                            r = requests.delete(delete_replica_endpoint, json={"socket-address": replica_ip})

    
# broadcast PUT request for new replica to be added to running replica's views
# if request fails for one replica (assume down)
# broadcasts DELETE request with downed replica's ip to all running replicas
def add_replica(ip):
    global view
    global up_replicas
    global down_replicas
    check_replicas()
    logging.info("\n\nINSIDE ADD REPLICA")
    logging.info(f"UP_REPLICAS: {up_replicas}")
    # initial GET requests to update views
    # do it for every single replica in the VIEW to help ensure downed replicas
    # for replica_ip in :
    #     # sync_view()
    #     if replica_ip == current_ip:
    #         view = set(view)
    #         view.add(replica_ip)
    #         view = list(view)
    # loop through updated view and send PUT requests to all running containers
    for replica_ip in up_replicas:
        logging.info(f"add_replica view: {view}")
        if replica_ip != current_ip:
            replica_endpoint = f"http://{replica_ip}/key-value-store-view"
            logging.info(f"update_view ip: {replica_endpoint}")
            try:
                requests.put(replica_endpoint, json={"socket-address": ip})
            except Exception as e:
                logging.info(f"INSIDE EXCEPTION OF ADD_REPLICA, downed replica: {replica_ip}")
                for v in view:
                    if current_ip != v:
                        target_replica = f"http://{v}/key-value-store-view"
                        if v != replica_ip:
                            r = requests.delete(target_replica, json={"socket-address": replica_ip})
    
    logging.info("done with adding everything")
    logging.info(f"VIEW AFTER INITIALIZING: {view}")


def broadcast_delete(target_ip):
    for ip in up_replicas:
        endpoint = f"http://{ip}/key-value-store-view"
        data = {"socket-address": target_ip}
        try_request(url=endpoint, data=data, method="DELETE")



def try_request(url=None, data=None, method=None, target_ip=None):
    global up_replicas, view, down_replicas
    logging.info(f"UP_RELICAS IN TRY_REQUEST: {up_replicas}")
    logging.info(f"DOWN_RELICAS IN TRY_REQUEST: {down_replicas}")
    logging.info(f"TARGET_IP: {target_ip}")
    logging.info(f"DATA: {data}")

    try:
        if method == 'PUT':
            requests.put(url, json=data)
            pass
        elif method == 'DELETE':
            requests.delete(url, json=data)
            pass
        elif method == 'GET':
            requests.get(url)
            pass
    except Exception as e:
        logging.info(f'ERROR: {e}')
        # found a downed replica
        # tell everyone to delete
        down_replicas = set(down_replicas)
        up_replicas = set(up_replicas)
        
        if target_ip not in down_replicas:
            down_replicas.add(target_ip)
        if target_ip in up_replicas:
            up_replicas.remove(target_ip)
            
        broadcast_delete(target_ip)
        
if __name__ == "__main__":
    # base case to prevent PUT requests to self
    logging.info(f"In container main function: {current_ip} {view}")
    # if current_ip not in view:
    add_replica(current_ip)
    
    app.run(host='0.0.0.0', port=8085, debug=True)